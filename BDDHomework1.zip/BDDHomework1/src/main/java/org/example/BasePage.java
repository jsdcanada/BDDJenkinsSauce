package org.example;

import org.openqa.selenium.WebDriver;

public class BasePage {
    protected static WebDriver driver;
}
